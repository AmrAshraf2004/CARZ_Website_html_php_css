
function showSidebar() {
    const sidebar = document.querySelector(".sidebar");
    sidebar.style.display ="flex";
    sidebar.style.transition = "0.8ms"
}

function hideSidebar() {
    const sidebar = document.querySelector(".sidebar");
    sidebar.style.display ="none";
    sidebar.style.transition = "0.8ms"
}




//details button

const cars = [
    {
        name: "porsche",
        model: "Model: Porsche 911",
        price: "Price: $200,000",
        color: "Color: silver",
        engine: "Engine: 2.5-liter inline-4",
        transmission: "Transmission: Automatic",
        fuel: "Fuel Efficiency: 28/39/34",
        seating: "Seating: 4 passengers"

    },
    {
        name: "bmw",
        model: "Model: BMW 2-series",
        price: "Price: $40,000",
        color: "Color: teal",
        engine: "Engine: 5.0-liter V8",
        transmission: "Transmission: Manual",
        fuel: "Fuel Efficiency: 15/24/18",
        seating: "Seating: 5 passengers"
    },
    {
        name: "mercedes",
        model: "Model: Mercedes Benz A",
        price: "Price: $80,000",
        color: "Color: blue",
        engine: "Engine: 1.5-liter inline-4",
        transmission: "Transmission: CVT",
        fuel: "Fuel Efficiency: 32/42/36",
        seating: "Seating: 5 passengers"
    },
    {
        name: "bugatti",
        model: "Model: Bugatti Veyron ",
        price: "Price: $1,900,000",
        color: "Color: black",
        engine: "Engine: 2.5-liter inline-4",
        transmission: "Transmission: Automatic",
        fuel: "Fuel Efficiency: 27/38/31",
        seating: "Seating: 2 passengers"
    },
    {
        name: "audi",
        model: "Model: Audi E-Tron GT",
        price: "Price: $110,000",
        color: "Color: silver",
        engine: "Engine: 6.2-liter V8",
        transmission: "Transmission: Automatic",
        fuel: "Fuel Efficiency: 15/27/19",
        seating: "Seating: 4 passengers"
    },
    {
        name: "lamborghini",
        model: "Model: Lamborghini Aventador",
        price: "Price: $376,000",
        color: "Color: orange",
        engine: "Engine: 2.0-liter inline-4",
        transmission: "Transmission: Automatic",
        fuel: "Fuel Efficiency: 26/36/30",
        seating: "Seating: 2 passengers"
    },
    {
        name: "peugeot",
        model: "Model: Peugut 301",
        price: "Price: $15,000",
        color: "Color: silver",
        engine: "Engine: 2.0-liter inline-4",
        transmission: "Transmission: Automatic",
        fuel: "Fuel Efficiency: 24/32/27",
        seating: "Seating: 5 passengers"
    },
    {
        name: "toyota",
        model: "Model: Toyota Yaris 2018",
        price: "Price: $17,000",
        color: "Color: red",
        engine: "Engine: 2.0-liter inline-4",
        transmission: "Transmission: Automatic",
        fuel: "Fuel Efficiency: 23/34/27",
        seating: "Seating: 5 passengers"
    },
    {
        name: "ford",
        model: "Model: Ford Focus",
        price: "Price: $17,000",
        color: "Color: blue",
        engine: "Engine: 1.4-liter inline-4",
        transmission: "Transmission: Automatic",
        fuel: "Fuel Efficiency: 29/36/32",
        seating: "Seating: 5 passengers"
    },
    {
        name: "hyundai",
        model: "Model: Hyundai Elantra",
        price: "Price: $23,000",
        color: "Color: black",
        engine: "Engine: 2.5-liter flat-4",
        transmission: "Transmission: CVT",
        fuel: "Fuel Efficiency: 26/33/29",
        seating: "Seating: 5 passengers"
    },
    {
        name: "chevrolet",
        model: "Model: Chevrolet Corvette",
        price: "Price: $70,000",
        color: "Color: red",
        engine: "Engine: Electric",
        transmission: "Transmission: Automatic",
        fuel: "Fuel Efficiency: 120 MPGe",
        seating: "Seating: 5 passengers"
    },
    {
        name: "volkswagen",
        model: "Model: Volkswagen Tiguan",
        price: "Price: $28,000",
        color: "Color: brown",
        engine: "Engine: Electric",
        transmission: "Transmission: Automatic",
        fuel: "Fuel Efficiency: 120 MPGe",
        seating: "Seating: 5 passengers"
    }
];

function displayDetails(carName) {

    var Car;

    for(var i = 0; i< cars.length; i++) {
        if(cars[i].name == carName) {
            car = cars[i];
            break;
        }
    }
    let detailsText = document.querySelector(`#detailsBox_${carName} .detailsText`);
    let detailsBox = document.getElementById(`detailsBox_${carName}`);
    if (detailsBox.style.display === 'block') {
        detailsBox.style.display = 'none';
    } else {
        detailsText.innerHTML = car.model + "<br>" + car.price + "<br>" + car.color + "<br>" + car.engine + "<br>" + car.transmission
        + "<br>" + car.fuel + "<br>" + car.seating;
        detailsBox.style.display = 'block';
    }
    
}

function closeDetails(carName) {
    let detailsBox = document.getElementById(`detailsBox_${carName}`);
    detailsBox.style.display = 'none';
    
}



var counter = 1;
var overlayText = document.getElementById("topText");

function next(){
	
	if(counter != 4){
		counter++;
	}
	else {
		counter = 1;
	}
    changeVideo();
    overlayText.textContent = "Hello World";
	
}

function prev(){
	
	if(counter != 1){
		counter--;
	}
	else {
		counter = 4;
	}
    changeVideo();
	
}

function changeVideo() {
    video.style.opacity = 0;
    setTimeout(function() {
        video.src = counter + ".mp4";
        video.style.opacity = 1;
    }, 500);
    
}



/*  Validation */

document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    const errorMessage = document.getElementById("error-message");

    form.addEventListener("submit", function(event) {
        event.preventDefault();

        if (validateForm()) {
            // If all validations pass, you can submit the form
            form.submit();
        } else {
            errorMessage.style.display = "block";
            
        }
    });

    function validateForm() {
        const nameInput = document.getElementById("name");
        const emailInput = document.getElementById("email");
        const passwordInput = document.getElementById("password");
        const confirmPasswordInput = document.getElementById("confirmPassword");

        const nameValue = nameInput.value.trim();
        const emailValue = emailInput.value.trim();
        const passwordValue = passwordInput.value.trim();
        const confirmPasswordValue = confirmPasswordInput.value.trim();

        // Regular expression for name validation: Only alphabets and spaces allowed, at least 2 characters
        const nameRegex = /^[a-zA-Z ]{2,30}$/;
        if (!nameRegex.test(nameValue)) {
            errorMessage.textContent = "Please enter a valid name.";
            return false;
        }

        // Regular expression for email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,40}$/;
        if (!emailRegex.test(emailValue)) {
            errorMessage.textContent = "Please enter a valid email address.";
            return false;
        }

        // Regular expression for password validation: At least 8 characters, at least one uppercase letter, one lowercase letter, and one number
        const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d]{8,40}$/;
        if (!passwordRegex.test(passwordValue)) {
            errorMessage.textContent = "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one number.";
            return false;
        }

        if (confirmPasswordValue !== passwordValue) {
            errorMessage.textContent = "Passwords do not match.";
            return false;
        }

        return true;
    }
});

