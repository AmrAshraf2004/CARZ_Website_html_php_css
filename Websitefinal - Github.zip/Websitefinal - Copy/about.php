<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="Style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" 
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src="JavaScript.js"></script>        
        <title>CarZ-About</title>
        <style>
            body {
                background-color: rgb(20,20,20);
                background-color: #070000;
            }

            .aboutContainer {
                display: grid;
                grid-template-columns: 1fr 1fr;
                background-color: rgb(3, 3, 3);
                background-color: rgb(5, 5, 5);
                background-color: #080000;
                border: ridge;
                border-width: 4px;
                border-color: rgb(250, 250, 210,0.5);
                opacity: 0.93;
                margin-left: 20px;
                margin-right: 20px;
            }

            .rightSide {
                margin-bottom: -30px;
            }

            .signBackground {
                border-right: ridge;
                border-width: 4px;
                border-color: rgb(250, 250, 210,0.5);
                height: 100%;
            }

            .signBackground:hover {
                transform: scale(1);
            }

            .footerContainer {
                background-color: #000000;
            }
            .copyrights {
                background-color: #030000;
            }

            h1 {
                color: rgb(228, 206, 178);
                text-align: center;
            }
            .fillerText {
                color: rgb(170, 170, 146);
                font-size: 26px;
            }

            .fas {
                margin-bottom: 15px;
            }

            @media (max-width: 1480px) and (min-width: 1280px) {
                .fillerText {
                    font-size: 20px;
                }
            }
            @media (max-width: 1280px) and (min-width: 400px) {
                .aboutContainer {
                    grid-template-columns: 1fr;
                }
                .signBackground {
                    border-right: none;
                    border-bottom: ridge;
                    border-width: 4px;
                    border-color: rgb(250, 250, 210,0.5);
                }
                .rightSide {
                    margin: 0;
                }
                .fillerText {
                    font-size: 20px;
                }
            }
        </style>
    </head>
    <body>
        <?php
        session_start();
        $isLoggedIn = isset($_SESSION['user_id']);
        ?>
        <nav class="navigationBar">
            <div class="navigationDiv">
                <div class="siteName"><a href="index.php">CAR<span class="Z">z</span></a></div>

                <ul class="sidebar">
                    <li onclick="hideSidebar()"><a href="#"><svg xmlns="http://www.w3.org/2000/svg" height="50" viewBox="0 -960 960 960" width="50" fill="crimson"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg></a></li>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contactus.php">Contact us</a></li>
                    <?php if ($isLoggedIn): ?>
                        <button class="login"><a href="logout.php">👤Logout</a></button>
                    <?php else: ?>
                        <button class="login"><a href="login.php">👤Login</a></button>
                    <?php endif; ?>
                </ul>

                <ul class="navbar">
                    <li class="hideOnMobile"><a href="index.php">Home</a></li>
                    <li class="hideOnMobile"><a href="cars.php">Cars</a></li>
                    <li class="hideOnMobile"><a href="about.php">About</a></li>
                    <li class="hideOnMobile"><a href="contactus.php">Contact us</a></li>
                    <?php if ($isLoggedIn): ?>
                        <button class="login hideOnMobile"><a href="logout.php">👤Logout</a></button>
                    <?php else: ?>
                        <button class="login hideOnMobile"><a href="login.php">👤Login</a></button>
                    <?php endif; ?>
                    <li onclick="showSidebar()"><a href="#"><svg class="showOnPC" xmlns="http://www.w3.org/2000/svg" height="45" viewBox="0 -960 960 960" width="45" fill="crimson"><path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/></svg></a></li>
                </ul>
            </div>
        </nav>
        <div class="backGroundAbout"></div>

        <div class="aboutUsHeaderContainer">
            <div class="aboutHeader">
                <h2>Our Services</h2>
            </div>
        </div>

        <div class="aboutUsContainer">
            <div class="aboutUsCard">
                <h2 class="serviceHeader"><i class="fas fa-car"></i><br> Sales</h2>
                <p class="serviceText">Explore our wide selection of new and used vehicles.</p>
            </div>
            <div class="aboutUsCard">
                <h2 class="serviceHeader"><i class="fas fa-wrench"></i><br> Maintenance</h2>
                <p class="serviceText">Keep your vehicle running smoothly with our maintenance services.</p>
            </div>
            <div class="aboutUsCard">
                <h2 class="serviceHeader"><i class="fas fa-headset"></i><br> Customer Support</h2>
                <p class="serviceText">Get assistance from our dedicated customer support team.</p>
            </div>
            <div class="aboutUsCard">
                <h2 class="serviceHeader"><i class="fas fa-brush"></i><br> Customization</h2>
                <p class="serviceText">Personalize your vehicle with our customization services.</p>
            </div>
            <div class="aboutUsCard">
                <h2 class="serviceHeader"><i class="fas fa-money-check-alt"></i><br> Financing</h2>
                <p class="serviceText">Provide financing options for customers like loans and installments.</p>
            </div>
        </div>

        <section id="about">
            <div class="aboutContainer">
                <div class="leftSide">
                    <img src="signBackground.png" alt="bugatti" class="signBackground">
                </div>
                <div class="rightSide">
                    <h1>Mission & Values</h1>
                    <p class="fillerText">
                        "Our mission at CarZ is to redefine the automotive experience for our customers.
                        We strive to provide unparalleled service, offering a diverse range of high-quality
                        vehicles coupled with exceptional customer care. Our commitment extends beyond sales
                        we aim to build lasting relationships with our customers by providing reliable maintenance
                        services, personalized assistance, and innovative solutions tailored to their needs.
                        With a dedication to excellence and a passion for automotive innovation, we are driven to 
                        exceed expectations and deliver the ultimate driving experience. At CarZ, our mission is not
                        just to sell cars, but to provide a journey of trust, satisfaction, and joy on the road ahead."
                    </p><br>
                </div>
            </div>
        </section>

        <footer id="contactUs">
            <div class="footerContainer">
                <div class="socialMedia">
                    <a href="https://www.facebook.com/MercedesBenz/"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://www.instagram.com/ferrari/?hl=en"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://www.pinterest.com/alonestar11/"><i class="fa-brands fa-pinterest"></i></a>
                    <a href="https://www.linkedin.com/company/mercedes-benz_ag"><i class="fa-brands fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/@MercedesBenz/featured"><i class="fa-brands fa-youtube"></i></a>
                </div>
                <div class="copyrights">
                    <p>Copyrights ©2024 CARZ | All rights reserved</p>
                </div>
            </div>
        </footer>
    </body>
</html>
