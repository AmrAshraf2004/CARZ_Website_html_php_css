<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="Style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" 
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
        <title>CarZ-Cars</title>
        <script src="JavaScript.js"></script>
    </head>
    <body>
        <?php
        session_start();
        $isLoggedIn = isset($_SESSION['user_id']);
        ?>
        <nav class="navigationBar">
            <div class="navigationDiv">
                <div class="siteName"><a href="index.php">CAR<span class="Z">z</span></a></div>

                <ul class="sidebar">
                    <li onclick="hideSidebar()"><a href="index.php"><svg xmlns="http://www.w3.org/2000/svg" height="50" viewBox="0 -960 960 960" width="50" fill="crimson"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg></a></li>
                    <li><a href="#home">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contactus.php">Contact us</a></li>
                    <?php if ($isLoggedIn): ?>
                        <button class="login"><a href="logout.php">👤Logout</a></button>
                    <?php else: ?>
                        <button class="login"><a href="login.php">👤Login</a></button>
                    <?php endif; ?>
                </ul>

                <ul class="navbar">
                    <li class="hideOnMobile"><a href="index.php">Home</a></li>
                    <li class="hideOnMobile"><a href="cars.php">Cars</a></li>
                    <li class="hideOnMobile"><a href="about.php">About</a></li>
                    <li class="hideOnMobile"><a href="contactus.php">Contact us</a></li>
                    <?php if ($isLoggedIn): ?>
                        <button class="login hideOnMobile"><a href="logout.php">👤Logout</a></button>
                    <?php else: ?>
                        <button class="login hideOnMobile"><a href="login.php">👤Login</a></button>
                    <?php endif; ?>
                    <li onclick="showSidebar()"><a href="#"><svg class="showOnPC" xmlns="http://www.w3.org/2000/svg" height="45" viewBox="0 -960 960 960" width="45" fill="crimson"><path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/></svg></a></li>
                </ul>
            </div>
        </nav>
        <div class="backGroundCar"></div>

        <div class="search-bar">
            <input type="text" class="search-input" placeholder="Search..." spellcheck="false" onkeyup="search()">
        </div>
        <div class="phrase-container">
            <p class="phrase">FEEL THE ADRENALINE & EMBRACE THE RIDE</p>
        </div>
        <div class="car-logos-container">
            <img src="Logos/bmwLogo.png" alt="Car Logo 1">
            <img src="Logos/porscheLogo.png" alt="Car Logo 2">
            <img src="Logos/audiLogo.png" alt="Car Logo 3">
            <img src="Logos/mercedesLogo.png" alt="Car Logo 4">
            <img src="Logos/PeugeotLogo.png" alt="Car Logo 5">
            <img src="Logos/lamborghini-logo.png" alt="Car Logo 6">
            <img src="Logos/toyotaLogo.png" alt="Car Logo 7">
            <img src="Logos/BugattiLogo.png" alt="Car Logo 8">
            <img src="Logos/fordLogo.png" alt="Car Logo 9">
            <img src="Logos/hyundaiLogo.png" alt="Car Logo 10">
            <img src="Logos/chevroletLogo.png" alt="Car Logo 11">
            <img src="Logos/VolkswagenLogo.png" alt="Car Logo 12">
        </div>

        <div class="cardContainer">
            <div class="card">
                <img src="images/porsche.jpg" alt="Car Image" class="carPorsche">
                <div class="card-details">
                    <h2 class="car-name">Porsche 911</h2>
                    <p class="car-price">$200,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="porsche" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_porsche"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
            <div class="card">
                <img src="images/bmw.jpg" alt="Car Image" class="carBMW">
                <div class="card-details">
                    <h2 class="car-name">BMW 2-series</h2>
                    <p class="car-price">$40,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="bmw" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_bmw"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
            <div class="card">
                <img src="images/mercedes.jpg" alt="Car Image" class="carMercedes">
                <div class="card-details">
                    <h2 class="car-name">Mercedes Benz A Class</h2>
                    <p class="car-price">$80,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="mercedes" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_mercedes"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
            <div class="card">
                <img src="images/bugatti.png" alt="Car Image" class="carBugatti">
                <div class="card-details">
                    <h2 class="car-name">Bugatti Veyron V16</h2>
                    <p class="car-price">$1,900,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="bugatti" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_bugatti"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="cardContainer">
            <div class="card">
                <img src="images/audi.png" alt="Car Image" class="carAudi">
                <div class="card-details">
                    <h2 class="car-name">Audi E-Tron GT</h2>
                    <p class="car-price">$110,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="audi" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_audi"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
            <div class="card">
                <img src="images/lamborghini.png" alt="Car Image" class="carLamborghini">
                <div class="card-details">
                    <h2 class="car-name">Lamborghini Aventador</h2>
                    <p class="car-price">$376,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="lamborghini" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_lamborghini"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
            <div class="card">
                <img src="images/peugeot.png" alt="Car Image" class="carPeugeot">
                <div class="card-details">
                    <h2 class="car-name">Peugeot 301</h2>
                    <p class="car-price">$15,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="peugeot" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_peugeot"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
            <div class="card">
                <img src="images/toyota.png" alt="Car Image" class="carToyota">
                <div class="card-details">
                    <h2 class="car-name">Toyota Yaris 2018</h2>
                    <p class="car-price">$17,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="toyota" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_toyota"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="cardContainer">
            <div class="card">
                <img src="images/ford.png" alt="Car Image" class="carFord">
                <div class="card-details">
                    <h2 class="car-name">Ford Focus</h2>
                    <p class="car-price">$17,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="ford" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_ford"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
            <div class="card">
                <img src="images/hyundai.png" alt="Car Image" class="carHyundai">
                <div class="card-details">
                    <h2 class="car-name">Hyundai Elantra</h2>
                    <p class="car-price">$23,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="hyundai" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_hyundai"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
            <div class="card">
                <img src="images/chevrolet.png" alt="Car Image" class="carChevrolet">
                <div class="card-details">
                    <h2 class="car-name">Chevrolet Corvette </h2>
                    <p class="car-price">$70,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="chevrolet" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_chevrolet"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
            <div class="card">
                <img src="images/volkswagen.png" alt="Car Image" class="carVolkswagen">
                <div class="card-details">
                    <h2 class="car-name">Volkswagen Tiguan</h2>
                    <p class="car-price">$28,000</p>
                    <div class="buttonFormat">
                        <button class="details" value="volkswagen" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                        <button class="favourites">❤</button>
                        <div class="detailsBox" id="detailsBox_volkswagen"><p class="detailsText"></p></div>
                    </div>
                </div>
            </div>
        </div>

        <footer id="contactUs">
            <div class="footerContainer">
                <div class="socialMedia">
                    <a href="https://www.facebook.com/MercedesBenz/"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://www.instagram.com/ferrari/?hl=en"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://www.pinterest.com/alonestar11/"><i class="fa-brands fa-pinterest"></i></a>
                    <a href="https://www.linkedin.com/company/mercedes-benz_ag"><i class="fa-brands fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/@MercedesBenz/featured"><i class="fa-brands fa-youtube"></i></a>
                </div>
            <div class="copyrights">
                <p>Copyrights ©2024 CARZ | All rights reserved</p>
            </div>
        </footer>
       

    </body>
</html>
