<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="Style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" 
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src="JavaScript.js"></script>
        <title>CarZ-ContactUs</title>
        <style>
            body {
                background-color: rgb(10,10,10);
                background-color: #02090c;
            }

            footer {
                position: relative;
                top: 30em;
            }

            .footerContainer {
                background-color: rgb(10,10,10);
                background-color: #02090c;
            }

            .socialMedia {
                background-color: rgb(10,10,10);
                background-color: #02090c;
                position: relative;
                top: 29em;
            }

            .copyrights {
                background-color: rgb(15,15,15);
                background-color: #040f14;
                margin-top: 40px;
            }
        </style>
    </head>
    <body>
        <?php
        session_start();
        $isLoggedIn = isset($_SESSION['user_id']);
        ?>
        <nav class="navigationBar">
            <div class="navigationDiv">
                <div class="siteName"><a href="index.php">CAR<span class="Z">z</span></a></div>

                <ul class="sidebar">
                    <li onclick="hideSidebar()"><a href="#"><svg xmlns="http://www.w3.org/2000/svg" height="50" viewBox="0 -960 960 960" width="50" fill="crimson"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg></a></li>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contactus.php">Contact us</a></li>
                    <?php if ($isLoggedIn): ?>
                        <button class="login"><a href="logout.php">👤Logout</a></button>
                    <?php else: ?>
                        <button class="login"><a href="login.php">👤Login</a></button>
                    <?php endif; ?>
                </ul>

                <ul class="navbar">
                    <li class="hideOnMobile"><a href="index.php">Home</a></li>
                    <li class="hideOnMobile"><a href="cars.php">Cars</a></li>
                    <li class="hideOnMobile"><a href="about.php">About</a></li>
                    <li class="hideOnMobile"><a href="contactus.php">Contact us</a></li>
                    <?php if ($isLoggedIn): ?>
                        <button class="login hideOnMobile"><a href="logout.php">👤Logout</a></button>
                    <?php else: ?>
                        <button class="login hideOnMobile"><a href="login.php">👤Login</a></button>
                    <?php endif; ?>
                    <li onclick="showSidebar()"><a href="#"><svg class="showOnPC" xmlns="http://www.w3.org/2000/svg" height="45" viewBox="0 -960 960 960" width="45" fill="crimson"><path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/></svg></a></li>
                </ul>
            </div>
        </nav>
        <div class="backGroundContactUs"></div>

        <div class="contactUsHeaderContainer">
            <div class="contactUsHeader">
                <h2>Contact us</h2>
            </div>
        </div>

        <div class="contactUsContainer">
            <div class="ContactCard">
                <h2 class="phoneHeader"><i class="fas fa-phone"></i> Phone</h2>
                <p class="phoneText">+20 117 254 8085</p>
                <p class="phoneText">+20 115 310 5005</p>
            </div>
            <div class="ContactCard">
                <h2 class="phoneHeader"><i class="fas fa-map-marker-alt"></i> Address</h2>
                <p class="phoneText">115 Cavendish Street, London, UK</p>
                <p class="phoneText">Station 321 Ottawa Ontario, Canada</p>
            </div>
            <div class="ContactCard">
                <h2 class="phoneHeader"><i class="far fa-envelope"></i> Email</h2>
                <p class="phoneText">carzvx91408@gmail.com</p>
                <p class="phoneText">carzCanv870@gmail.com</p>
            </div>
        </div>

        <div class="socialMedia">
            <a href="https://www.facebook.com/MercedesBenz/"><i class="fa-brands fa-facebook"></i></a>
            <a href="https://www.instagram.com/ferrari/?hl=en"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://www.pinterest.com/alonestar11/"><i class="fa-brands fa-pinterest"></i></a>
            <a href="https://www.linkedin.com/company/mercedes-benz_ag"><i class="fa-brands fa-linkedin"></i></a>
            <a href="https://www.youtube.com/@MercedesBenz/featured"><i class="fa-brands fa-youtube"></i></a>
        </div>

        <footer id="contactUs">
            <div class="footerContainer">
                <div class="copyrights">
                    <p>Copyrights ©2024 CARZ | All rights reserved</p>
                </div>
            </div>
        </footer>
    </body>
</html>
