<?php
$servername = "localhost:3306";
$username = "phpMyAdmin";
$password = "Vampire1899#";
$dbname = "carz";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
