<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="Style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" 
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src="JavaScript.js"></script>

        <title>CarZ</title>
    </head>
    <body>
        <?php
        session_start();
        $isLoggedIn = isset($_SESSION['user_id']);
        ?>
        <nav class="navigationBar">
            <div class="navigationDiv">
                <div class="siteName"><a href="index.php">CAR<span class="Z">z</span></a></div>

                <ul class="sidebar">
                    <li onclick="hideSidebar()"><a href="#"><svg xmlns="http://www.w3.org/2000/svg" height="50" viewBox="0 -960 960 960" width="50" fill="crimson"><path d="m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z"/></svg></a></li>
                    <li><a href="#home">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contactus.php">Contact us</a></li>
                    <?php if ($isLoggedIn): ?>
                        <button class="login"><a href="logout.php">👤Logout</a></button>
                    <?php else: ?>
                        <button class="login"><a href="login.php">👤Login</a></button>
                    <?php endif; ?>
                </ul>

                <ul class="navbar">
                    <li class="hideOnMobile"><a href="#home">Home</a></li>
                    <li class="hideOnMobile"><a href="cars.php">Cars</a></li>
                    <li class="hideOnMobile"><a href="about.php">About</a></li>
                    <li class="hideOnMobile"><a href="contactus.php">Contact us</a></li>
                    <?php if ($isLoggedIn): ?>
                        <button class="login hideOnMobile"><a href="logout.php">👤Logout</a></button>
                    <?php else: ?>
                        <button class="login hideOnMobile"><a href="login.php">👤Login</a></button>
                    <?php endif; ?>
                    <li onclick="showSidebar()"><a href="#"><svg class="showOnPC" xmlns="http://www.w3.org/2000/svg" height="45" viewBox="0 -960 960 960" width="45" fill="crimson"><path d="M120-240v-80h720v80H120Zm0-200v-80h720v80H120Zm0-200v-80h720v80H120Z"/></svg></a></li>
                </ul>
            </div>
        </nav>

        <section id='home'>
            <div class="videoContainer">
                <video id="video" autoplay muted>
                    <source src="1.mp4" type="video/mp4">
                </video>
                <script>
                video.addEventListener('ended', function() {
                    next(); // switches video when the current video ends
                });
                </script>
                
                <div class="overlay">
                    <h1 id="topText">READY SET GO!</h1>
                </div>
            </div>
            <a class="prev" onclick="prev()">&#10094;</a>
            <a class="next" onclick="next()">&#10095;</a>
        </section>
        <section id="cars">
            <h1 id="carTitle">FEATURED<span class="redColor">CARS</span></h1>
            <div class="cardContainer">
                <div class="card">
                    <img src="images/porsche.jpg" alt="Car Image" class="carPorsche">
                    <div class="card-details">
                        <h2 class="car-name">Porsche 911</h2>
                        <p class="car-price">$200,000</p>
                        <div class="buttonFormat">
                            <button class="details" value="porsche" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                            <button class="favourites">❤</button>
                            <div class="detailsBox" id="detailsBox_porsche"><p class="detailsText"></p></div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <img src="images/bmw.jpg" alt="Car Image" class="carBMW">
                    <div class="card-details">
                        <h2 class="car-name">BMW 2-series</h2>
                        <p class="car-price">$40,000</p>
                        <div class="buttonFormat">
                            <button class="details" value="bmw" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                            <button class="favourites">❤</button>
                            <div class="detailsBox" id="detailsBox_bmw"><p class="detailsText"></p></div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <img src="images/mercedes.jpg" alt="Car Image" class="carMercedes">
                    <div class="card-details">
                        <h2 class="car-name">Mercedes Benz A Class</h2>
                        <p class="car-price">$80,000</p>
                        <div class="buttonFormat">
                            <button class="details" value="mercedes" onclick="displayDetails(value)" onmouseleave="closeDetails(value)">View Details</button>
                            <button class="favourites">❤</button>
                            <div class="detailsBox" id="detailsBox_mercedes"><p class="detailsText"></p></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carsLinkContainer">
                <a id="carsLink" href="cars.php">View All ⮞</a>
            </div>
        </section>
        <section id="about">
            <div class="aboutContainer">
                <div class="leftSide">
                    <img src="images/bugatti.png" alt="bugatti" class="bugattiImage">
                </div>
                <div class="rightSide">
                    <h1>ABOUT <span class="us">US</span></h1>
                    <p class="fillerText">
                        Welcome to CarZ, your premier destination for quality cars and automotive excellence.
                        At CarZ, we are passionate about providing our customers with a seamless and enjoyable
                        experience as they embark on the journey of finding their dream vehicle. Commited
                        to offering a diverse range of vehicles, our showroom showcases the latest models from leading manufacturers.
                    </p><br>
                    <a id="carsLink" href="about.php">READ MORE ⮞</a>
                </div>
            </div>
        </section>
        <footer id="contactUs">
            <div class="footerContainer">
                <div class="socialMedia">
                    <a href="https://www.facebook.com/MercedesBenz/"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://www.instagram.com/ferrari/?hl=en"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://www.pinterest.com/alonestar11/"><i class="fa-brands fa-pinterest"></i></a>
                    <a href="https://www.linkedin.com/company/mercedes-benz_ag"><i class="fa-brands fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/@MercedesBenz/featured"><i class="fa-brands fa-youtube"></i></a>
                </div>
                <div class="copyrights">
                    <p>Copyrights ©2024 CARZ | All rights reserved</p>
                </div>
            </div>
        </footer>
    </body>
</html>
