<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>CARZ-login</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const loginForm = document.getElementById("loginForm");
            const errorMessageLogin = document.getElementById("error-message-login");
            const successMessageLogin = document.getElementById("success-message-login");

            // Display server-side error message if present
            <?php if (isset($_SESSION['error_message'])) { ?>
                errorMessageLogin.textContent = "<?php echo $_SESSION['error_message']; ?>";
                errorMessageLogin.style.display = "block";
                <?php unset($_SESSION['error_message']); ?>
            <?php } ?>

            if (loginForm) {
                loginForm.addEventListener("submit", function(event) {
                    event.preventDefault();

                    if (validateLogin()) {
                        
                        successMessageLogin.style.display = "block";
                        errorMessageLogin.style.display = "none";
                        loginForm.submit();
                    } else {
                        errorMessageLogin.style.display = "block";
                        successMessageLogin.style.display = "none";
                    }
                });
            }

            function validateLogin() {
                const emailInput = document.getElementById("login-email");
                const passwordInput = document.getElementById("login-password");

                const emailValue = emailInput.value.trim();
                const passwordValue = passwordInput.value.trim();

                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,40}$/;
                const passwordRegex = /^(?=.*\d)(?=.*[a-zA-Z])[a-zA-Z\d]{8,}$/;

                if (!emailRegex.test(emailValue)) {
                    errorMessageLogin.textContent = "Please enter a valid email address.";
                    return false;
                }

                if (!passwordRegex.test(passwordValue)) {
                    errorMessageLogin.textContent = "Password must be at least 8 characters long and contain at least one letter and one number.";
                    return false;
                }

                return true;
            }
        });
    </script>
    <style>
        body {
            padding-left: 400px;
            padding-top: 930px;
            background-image: url("images/photo6.jpg");
            background-repeat: no-repeat;
            background-size: cover;;
            background-position: center; 
        }

        form h2 {
            font-family: "Calibri", sans-serif;
            font-size: 40px;
            font-weight: 900;
            color: azure;
            text-decoration: none;
            padding-left: 10px;
            font-style: italic;
            text-align: center;
        }

        form h2 .z {
            font-family: "Calibri", sans-serif;
            font-style: italic;
            font-weight: 900;
            font-size: 44px;
            color: crimson;
        }

        form {
            height: 550px;
            width: 400px;
            background-color: rgba(100,100,100,0.6);
            position: fixed;
            transform: translate(-50%,-50%);
            top: 50%;
            left: 50%;
            border-radius: 10px;
            backdrop-filter: blur(0.3px);
            border: 2px solid rgba(255,255,255,0.1);
            box-shadow: 0 0 40px rgba(8,7,16,0.6);
            padding: 50px 35px;
            display: flex;
            flex-direction: column;
            align-items: center;
            font-family: 'Poppins',sans-serif;
            color: ghostwhite;
        }

        * {
            font-family: 'Poppins',sans-serif;
            color: ghostwhite;
            letter-spacing: 0.5px;
            outline: none;
            border: none;
        }

        form h3 {
            font-size: 32px;
            font-weight: 500;
            line-height: 42px;
        }

        label {
            display: block;
            margin-top: 20px; 
            font-size: 16px;
            font-weight: 500;
            text-align: left; 
            width: 100%; 
        }

        input {
            display: block;
            height: 50px;
            width: 100%;
            background-color: rgba(255,255,255,0.07);
            border-radius: 3px;
            padding: 0 10px;
            margin-top: 8px;
            font-size: 14px;
            font-weight: 300;
        }

        ::placeholder {
            color: #e5e5e5;
        }

        button {
            margin-top: 20px;
            width: 100%;
            background-color: rgb(230, 230, 230,0.9);
            color: #080710;
            padding: 15px 0;
            font-size: 18px;
            font-weight: 600;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            transform: scale(1.05);
            background-color: rgb(230, 230, 230,1);
        }

        .signup {
            margin-top: 20px;
            text-align: center;
            color: ghostwhite;
            font-size: 14px;
        }

        a {
            font-weight: bold;
            color: rgb(248, 248, 255,0.9);
            text-decoration: none;
        }

        a:hover {
            color: ghostwhite;
        }

        .social {
            margin-top: 30px;
            display: flex;
        }

        .social div {
            background: red;
            width: 150px;
            border-radius: 3px;
            padding: 5px 10px 10px 5px;
            background-color: rgba(255,255,255,0.27);
            color: #eaf0fb;
            text-align: center;
        }

        .social div:hover {
            background-color: rgba(255,255,255,0.57);
            color: firebrick;
        }

        .social .fb {
            margin-left: 25px;
        }

        .go:hover * {
            color: firebrick;
        }

        .fb:hover * {
            color: firebrick;
        }

        .social i {
            margin-right: 4px;
        }
    </style>
</head>
<body>
    <div class="background"></div>
    <form action="login_handler.php" method="post" id="loginForm" autocomplete="off">
        <h2>CAR<span class="z">Z</span></h2>
        <div id="error-message-login" style="display:none; color:red;"></div>
        <div id="success-message-login" style="display:none; color:green;"></div>
        <label for="login-email">Email</label>
        <input type="email" id="login-email" name="email" required>

        <label for="login-password">Password</label>
        <input type="password" id="login-password" name="password" required>

        <button type="submit">Login</button>
        <div class="signup">Don't have an account? <a href="signup.php">Sign Up</a></div>
    </form>
</body>
</html>
