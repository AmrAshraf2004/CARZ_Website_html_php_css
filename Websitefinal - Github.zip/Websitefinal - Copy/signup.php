<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>CARZ-signup</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <link rel="icon" href="images/search.svg" type="">
    <script src="JavaScript.js"></script>
    <style>
        body {
            padding-top: 800px;
            background-image: url("images/photo1.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            margin-bottom: 0;
        }

        form h2 {
            font-family: "Calibri", sans-serif;
            font-size: 40px;
            font-weight: 900;
            color: azure;
            text-decoration: none;
            padding-left: 10px;
            font-style: italic;
            text-align: center;
            margin-bottom: 10px;
        }

        form h2 .z {
            font-family: "Calibri", sans-serif;
            font-style: italic;
            font-weight: 900;
            font-size: 44px;
            color: crimson;
        }

        form {
            height: 600px;
            width: 400px;
            background-color: rgba(100,100,100,0.6);
            position: fixed;
            transform: translate(-50%, -50%);
            top: 50%;
            left: 51%;
            border-radius: 10px;
            backdrop-filter: blur(0.7px);
            border: 2px solid rgba(255,255,255,0.1);
            box-shadow: 0 0 40px rgba(8,7,16,0.6);
            padding: 34px 80px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        * {
            font-family: 'Poppins', sans-serif;
            color: ghostwhite;
            letter-spacing: 0.5px;
            line-height: 40px;
            outline: none;
            border: none;
        }

        label {
            display: block;
            margin-top: 10px;
            font-size: 16px;
            font-weight: 500;
            text-align: left;
            width: 100%;
        }

        input {
            display: block;
            height: 40px;
            width: 100%;
            background-color: rgba(255,255,255,0.20);
            border-radius: 5px;
            padding: 0 15px;
            margin-top: 8px;
            font-size: 14px;
            font-weight: 300;
            box-sizing: border-box;
        }

        ::placeholder {
            color: #e5e5e5;
        }

        button {
            margin-top: 20px;
            width: 100%;
            background-color: rgb(230, 230, 230,0.9);
            color: #080710;
            padding: 15px 0;
            font-size: 18px;
            font-weight: 600;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }

        button:hover {
            transform: scale(1.05);
            background-color: rgb(230, 230, 230,1);
        }

        .signup {
            margin-top: 10px;
            text-align: center;
            color: #ffffff;
            font-size: 14px;
        }

        a {
            font-weight: bold;
            color: silver;
        }

        a:hover {
            color: ghostwhite;
        }

        /* Error message display */
        #error-message {
            display: none;
            font-family: Verdana, Tahoma, sans-serif;
            font-weight: bold;
            background-color: gray;
            color: red;
            text-align: center;
        }

        /* Success message display */
        #success-message {
            display: none;
            font-family: Verdana, Tahoma, sans-serif;
            font-weight: bold;
            background-color: gray;
            color: green;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="background"></div>
    <form action="signup_handler.php" id="signupForm" method="post" autocomplete="off">
        <!-- Error message display -->
        <div id="error-message" <?php if (isset($_SESSION['error_message'])) echo 'style="display: block;"'; ?>>
            <?php
            if (isset($_SESSION['error_message'])) {
                echo $_SESSION['error_message'];
                unset($_SESSION['error_message']);
            }
            ?>
        </div>
        <!-- Success message display -->
        <div id="success-message" <?php if (isset($_SESSION['success_message'])) echo 'style="display: block;"'; ?>>
            <?php
            if (isset($_SESSION['success_message'])) {
                echo $_SESSION['success_message'];
                unset($_SESSION['success_message']);
            }
            ?>
        </div>

        <input autocomplete="false" name="hidden" type="text" style="display:none;">
        <h2>CAR<span class="z">Z</span></h2>

        <label for="nameSignup">Name</label>
        <input type="text" placeholder="Name" id="name" name="name" required>

        <label for="emailSignup">Email</label>
        <input type="email" placeholder="Email" id="email" name="email" required>

        <label for="passwordSignup">Password</label>
        <input type="password" placeholder="Password" id="password" name="password" required>

        <label for="confirmPasswordSignup">Confirm Password</label>
        <input type="password" placeholder="Confirm Password" id="confirmPassword" name="confirmPassword" required>
        
        <button type="submit">Sign Up</button>
        <div class="signup">Already have an account? <a href="login.php">LogIn</a></div>
    </form>
</body>
</html>
