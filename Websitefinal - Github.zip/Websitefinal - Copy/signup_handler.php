<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirmPassword = trim($_POST['confirmPassword']);

    // Validate input
    if ($password !== $confirmPassword) {
        $_SESSION['error_message'] = "Passwords do not match.";
        header("Location: signup.php");
        exit();
    }

    // Regular expression for name validation: Only alphabets and spaces allowed, at least 2 characters
    if (!preg_match("/^[a-zA-Z ]{2,30}$/", $name)) {
        $_SESSION['error_message'] = "Please enter a valid name.";
        header("Location: signup.php");
        exit();
    }

    // Regular expression for email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error_message'] = "Please enter a valid email address.";
        header("Location: signup.php");
        exit();
    }

    // Regular expression for password validation: At least 8 characters, at least one uppercase letter, one lowercase letter, and one number
    if (!preg_match("/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d]{8,40}$/", $password)) {
        $_SESSION['error_message'] = "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one number.";
        header("Location: signup.php");
        exit();
    }

    // Check if user already exists
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['error_message'] = "A user with this email already exists.";
        header("Location: signup.php");
        exit();
    }

    $stmt->close();

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert into database
    $sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $name, $email, $hashed_password);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Registration successful.";
        header("Location: login.php");
    } else {
        $_SESSION['error_message'] = "Error: " . $stmt->error;
        header("Location: signup.php");
    }

    $stmt->close();
    $conn->close();
}
?>
